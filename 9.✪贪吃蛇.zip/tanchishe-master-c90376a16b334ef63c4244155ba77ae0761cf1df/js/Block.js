// 障碍物
function Block(img){
     this.arr = [
     {row: 5, col: 5},
     {row: 5, col: 6},
     {row: 5, col: 7},
     {row: 5, col: 8},
     {row: 5, col: 9},
     {row: 6, col: 5},
     {row: 7, col: 5},
     {row: 8, col: 5},
     {row: 9, col: 5},


     ];
     this.img = img;
}
